// #include<stdio.h>
main()
{
int INP0;
int OUTP;   
int INP1, INP2, INP3, INP4, INP5, INP6, ACC0, ACC1, ACC2, ACC3, ACC4, ACC5;

                ACC0 = INP6 * -1870;
                ACC2 = (INP4 * -740) + ACC1;
                ACC3 = (INP3 * -1804) + ACC2;
                ACC4 = (INP2 * -740) + ACC3;
                OUTP = (INP0 * -1870) + ACC5;
                ACC1 = ACC0 - (INP5 * -1867);
                ACC5 = ACC4 - (INP1 * -1867);
                INP6 = INP5;
                INP5 = INP4;
                INP4 = INP3;
                INP3 = INP2;
                INP2 = INP1;
                INP1 = INP0;

}
