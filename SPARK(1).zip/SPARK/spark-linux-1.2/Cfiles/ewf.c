 #include<stdio.h>
main()
{

   // int m1=1, m2=1, m3=1, m4=1, m5=1, m6=1, m7=1, m8=1, i=1;
    int n1, n2, n3, n4, n5, n6, n7;
    int n8, n9, n10, n11, n12, n13;
    int n14, n15, n16, n17, n18, n19;
    int n20, n21, n22, n23, n24, n25;
    int n26, n27, n28, n29;
    int inp;
    int outp;
    int sv2, sv13, sv18, sv26, sv33, sv38, sv39;
    int sv2_o, sv13_o, sv18_o, sv26_o, sv33_o, sv38_o, sv39_o;


    n1 = inp + sv2;
    n2 = sv33 + sv39;
    n3 = n1 + sv13;
    n4 = n3 + sv26;
    n5 = n4 + n2;
    n6 = n5 * 4;
    n7 = n5 * 5;
    n8 = n3 + n6;
    n9 = n7 + n2;
    n10 = n3 + n8; 
    n11 = n8 + n5;
    n12 = n2 + n9;
    n13 = n10 * 3;
    n14 = n12 * 6;
    n15 = n1 + n13;
    n16 = n14 + sv39;
    n17 = n1 + n15;
    n18 = n15 + n8;
    n19 = n9 + n16;
    n20 = n16 + sv39;
    n21 = n17 * 5;
    n22 = n18 + sv18;
    n23 = sv38 + n19;
    n24 = n20 * 7;
    n25 = inp + n21;
    n26 = n22 * 5;
    n27 = n23 * 9;
    n28 = n26 + sv18;
    n29 = n27 + sv38; 
    sv2_o = n25 + n15;
    sv13_o = n17 + n28;
    sv18_o = n28;
    sv26_o = n9 + n11; 
    sv38_o = n29;
    sv33_o = n19 + n29;
    sv39_o = n16 + n24;
    outp = n24;

}
