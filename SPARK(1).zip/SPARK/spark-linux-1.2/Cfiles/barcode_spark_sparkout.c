
extern int main(void);
extern void _main();

int main(void)
{
 int reset;
 int clk;
 int scan;
 int video;
 int start;
 int num;
 int eoc;
 int memw;
 int data;
 int addr;
 int white;
 int black;
 int actnum;
 int flag;
 int wh;
 int bl;
 int eop;
 int breakflag;
 int sT0_25;
 int sT1_28;
 int sT2_30;
 int sT3_32;
 int sT4_37;
 int sT5_43;
 int sT6_46;
 int sT7_46;
 int sT8_46;
 int sT9_46;
 int sT10_46;
 int sT11_46;
 int sT12_46;
 int sT13_49;
 int sT14_51;
 int sT15_54;
 int sT16_59;
 int sT17_63;
 int sT18_72;
 int sT19_72;
 int sT20_72;
 int sT21_72;
 int sT22_72;
 int sT23_72;
 int sT24_72;
 int sT25_74;
 int sT26_76;
 int sT27_79;
 int sT28_86;
 int sT29_100;
 int sT30_103;
 int sT31_110;
 int sT32_122;
 int sT33_134;
 int sT34_140;
 int sT35_140;
 int sT36_140;
 int sT37_142;
 int sT38_145;
 int sT39_150;
 int sT40_46;
 int sT41_46;
 int sT42_46;
 int sT43_46;
 int sT44_46;
 int sT45_72;
 int sT46_72;
 int sT47_72;
 int sT48_72;
 int sT49_72;
 int sT50_140;
 int sT51_140;

 int returnVar_main;
  wh = 0;
  bl = 1;
  eoc = 0;
  memw = 0;
  data = 0;
  addr = 0;
  eop = 0;
  do
   {
    sT0_25 = (eop == 0);
    if (sT0_25)
     {
      breakflag = 0;
      do
       {
        sT1_28 = (breakflag != 1);
        if (sT1_28)
         {
          do
           {
            sT2_30 = (clk != 1);
            if (sT2_30)
             {
              1;
             }              /* end of loop condition */
            else
              break;
           } while (1);

          sT3_32 = (reset == 1);
          eop = 0;
          if (sT3_32)
           {
            eop = 1;
            breakflag = 1;
           }  /* end of if-else (sT3_32)*/
          sT4_37 = (start == 1);
          if (sT4_37)
           {
            breakflag = 1;
           }  /* end of if-else (sT4_37)*/
          1;
         }          /* end of loop condition */
        else
          break;
       } while (1);

      sT5_43 = (eop == 0);
      if (sT5_43)
       {
        breakflag = 0;
        do
         {
          sT40_46 = (white != 255);
          sT8_46 = sT40_46;
          sT41_46 = (actnum != num);
          sT9_46 = sT41_46;
          sT10_46 = ((sT41_46) && (sT40_46));
          sT42_46 = (breakflag == 0);
          sT7_46 = sT42_46;
          sT43_46 = (eop == 0);
          sT6_46 = sT43_46;
          sT44_46 = ((sT10_46) && (sT42_46));
          sT11_46 = sT44_46;
          sT12_46 = ((sT44_46) && (sT43_46));
          if (sT12_46)
           {
            breakflag = 0;
            do
             {
              sT13_49 = (breakflag != 1);
              if (sT13_49)
               {
                do
                 {
                  sT14_51 = (clk != 1);
                  if (sT14_51)
                   {
                    1;
                   }                    /* end of loop condition */
                  else
                    break;
                 } while (1);

                sT15_54 = (reset == 1);
                eop = 0;
                if (sT15_54)
                 {
                  eop = 1;
                  breakflag = 1;
                 }  /* end of if-else (sT15_54)*/
                sT16_59 = (scan == 1);
                if (sT16_59)
                 {
                  breakflag = 1;
                 }  /* end of if-else (sT16_59)*/
                1;
               }                /* end of loop condition */
              else
                break;
             } while (1);

            sT17_63 = (eop == 0);
            if (sT17_63)
             {
              flag = 0;
              actnum = 0;
              white = 0;
              black = 0;
              eoc = 0;
              breakflag = 0;
              do
               {
                sT45_72 = (breakflag == 0);
                sT19_72 = sT45_72;
                sT46_72 = (black != 255);
                sT20_72 = sT46_72;
                sT21_72 = ((sT46_72) && (sT45_72));
                sT47_72 = (eop == 0);
                sT18_72 = sT47_72;
                sT49_72 = (white != 255);
                sT23_72 = sT49_72;
                sT48_72 = ((sT21_72) && (sT47_72));
                sT22_72 = sT48_72;
                sT24_72 = ((sT49_72) || (sT48_72));
                if (sT24_72)
                 {
                  sT25_74 = (video == 0);
                  if (sT25_74)
                   {
                    do
                     {
                      sT26_76 = (clk != 1);
                      if (sT26_76)
                       {
                        1;
                       }                        /* end of loop condition */
                      else
                        break;
                     } while (1);

                    sT27_79 = (reset == 1);
                    eop = 0;
                    if (sT27_79)
                     {
                      eop = 1;
                      breakflag = 1;
                     }  /* end of if-else (sT27_79)*/
                    white = (white + 1);
                    sT28_86 = (flag == 1);
                    if (sT28_86)
                     {
                      actnum = (actnum + 1);
                      memw = 0;
                     } /* sT28_86                     */
                    else
                     {
                      memw = 1;
                     }  /* end of if-else (sT28_86)*/
                    black = 0;
                    flag = 0;
                    data = white;
                   } /* sT25_74                   */
                  else
                   {
                    do
                     {
                      sT29_100 = (clk != 1);
                      if (sT29_100)
                       {
                        1;
                       }                        /* end of loop condition */
                      else
                        break;
                     } while (1);

                    sT30_103 = (reset == 1);
                    eop = 0;
                    if (sT30_103)
                     {
                      eop = 1;
                      breakflag = 1;
                     }  /* end of if-else (sT30_103)*/
                    black = (black + 1);
                    sT31_110 = (flag == 0);
                    if (sT31_110)
                     {
                      actnum = (actnum + 1);
                      memw = 0;
                     } /* sT31_110                     */
                    else
                     {
                      memw = 1;
                     }  /* end of if-else (sT31_110)*/
                    flag = 1;
                    white = 0;
                    data = black;
                   }  /* end of if-else (sT25_74)*/
                  sT32_122 = (eop == 0);
                  if (sT32_122)
                   {
                    addr = actnum;
                   }  /* end of if-else (sT32_122)*/
                  1;
                 }                  /* end of loop condition */
                else
                  break;
               } while (1);

             }  /* end of if-else (sT17_63)*/
            1;
           }            /* end of loop condition */
          else
            break;
         } while (1);

        sT33_134 = (eop == 0);
        if (sT33_134)
         {
          memw = 0;
          eoc = 1;
          breakflag = 0;
          do
           {
            sT50_140 = (breakflag == 0);
            sT34_140 = sT50_140;
            sT51_140 = (start != 0);
            sT35_140 = sT51_140;
            sT36_140 = ((sT51_140) && (sT50_140));
            if (sT36_140)
             {
              do
               {
                sT37_142 = (clk != 1);
                if (sT37_142)
                 {
                  1;
                 }                  /* end of loop condition */
                else
                  break;
               } while (1);

              sT38_145 = (reset == 1);
              eop = 0;
              if (sT38_145)
               {
                eop = 1;
                breakflag = 1;
               }  /* end of if-else (sT38_145)*/
              sT39_150 = (start == 0);
              if (sT39_150)
               {
                breakflag = 1;
               }  /* end of if-else (sT39_150)*/
              1;
             }              /* end of loop condition */
            else
              break;
           } while (1);

         }  /* end of if-else (sT33_134)*/
       }  /* end of if-else (sT5_43)*/
      1;
     }      /* end of loop condition */
    else
      break;
   } while (1);

  returnVar_main = 0;
  return   0;

}

