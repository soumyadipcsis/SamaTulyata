//#include<stdio.h>
main()
{
int i0, i1, i2, i3, i4, i5, i6, i7;
int o0, o1, o2, o3, o4, o5, o6, o7;
int a0, a7, b1, a2, a3, a4, a6, b0, c4, d2, b6, d3, c7, d0, d1, c5, c6, d4, d6, d5, d7, r2, q3, q2, r3; 
int r4, q5, q4, r5, r6, q7, q6, r7, b5; 

a0 = i0 + i7;
a7 = i0 - i7;
b1 = i1 + i2;
a2 = i1 - i2;
a3 = i3 + i4;
a4 = i3 - i4;
b5 = i5 + i6;
a6 = i5 - i6;
b0 = a0 + a4;
c4 = a0 - a4;
d2 = a2 + a6;
b6 = a2 - a6;
d3 = a3 + a7;
c7 = a3 - a7;
d0 = b0 + b1;
d1 = b0 - b1;
c5 = b5 * 0.7071;
c6 = b6 * 0.7071;
d4 = c4 + c6;
d6 = c4 - c6;
d5 = c5 + c7;
d7 = c5 - c7;
o4 = d0 * 0.7071;
o0 = d1 * 0.7071;
r2 = d2 * 0.5;
q3 = d3 * 0.4;
o2 = r2 + q3;
q2 = d2 * 0.4;
r3 = d3 * 0.5;
o6 = q2 - r3;
r4 = d4 * 0.5;
q5 = d5 * 0.4;
o1 = r4 + q5;
q4 = d4 * 0.4;
r5 = d5 * 0.5;
o7 = q4 - r5;
r6 = d6 * 0.5;
q7 = d7 * 0.4;
o3 = r6 + q7;
q6 = d6 * 0.4;
r7 = d7 * 0.5;
o5 = q6 - r7;
}
