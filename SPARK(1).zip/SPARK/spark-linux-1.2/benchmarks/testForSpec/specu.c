
main()
{
  int a, b, c, d, x, y, i;
  a=b+c;
  
  if(b>c)
  {
    d=d+10;
    c=b-d;
  }
  else
  {
    c=a+d;
  }
  if(x<y)
  {
	x=x+y;
	y=x-c;
  }
  else
  {
	x=x+y;
	y=x+c;
  }
}
