int main()
{
int a, b, c, d, p, q, x, y, e, i, j, m, l, h, n, f, g;
a = a + 5;
d = 2*a;
b = x + y;

if(p>q)
{
	f= x+d;
}
else
{ 
	c = y - x;
	if(p==q)
	{ 
		g=d-12;
		e=b-x;
		i=g+e;
		j=i/5;	
	}
	else
	{
		h=c-b;
	}
	m=h*j;
}
n=f+m;
}
