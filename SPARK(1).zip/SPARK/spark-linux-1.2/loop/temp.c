#include <stdio.h>

int main()
{
  int i;
  for(i=0; i<100; i++)
     printf("\nin2[%d] = %d;", i , i);

}