#!/bin/sh

if [ ! -f `which spark` ] 
then
echo "Could not find the Spark executable in your path.  Please set path"
echo "to include the Spark executable"
echo "Exiting ...."
exit 1
fi

# NOTE: We are using the -m command line flag since motionvector_forSpark.c
#       uses old-style C function declarations
echo "spark -m -hli -hcs -hcp -hdc -hs -hcc -hvf -hb -hec motionvector_forSpark.c &> spark.log"
spark -m -hli -hcs -hcp -hdc -hs -hcc -hvf -hb -hec motionvector_forSpark.c &> spark.log

echo ""
echo "#############################################################"
echo "Finished running SPARK on the Motion Compensation Algorithm"
echo "See spark.log for warnings and errors."
echo "Starting make of MPEG player source.  See log in make.log"
echo "#############################################################"

\rm -f make.log

echo "make depend >> make.log 2>&1"
make depend >> make.log 2>&1
echo "make all >> make.log 2>&1"
make all >> make.log 2>&1
echo "make forspark >> make.log 2>&1"
make forspark >> make.log 2>&1
echo "make afterspark >> make.log 2>&1"
make afterspark >> make.log 2>&1

\cp -f output/motionvector_forSpark_spark_rtl.vhd ../synops/src
echo ""
echo "#############################################################"
echo "Finished running tutorial example"
echo "There are three versions of mpeg_play available now: "
echo "mpeg_play-orig, mpeg_play-forspark and mpeg_play-afterspark"
echo "You can play the MPEG smoker.mpg as follows:"
echo "./mpeg_play-orig smoker.mpg"
echo "./mpeg_play-forspark smoker.mpg"
echo "./mpeg_play-afterspark smoker.mpg"
echo "You can run Logic Synthesis on the output VHDL file: "
echo "        output/motionvector_forSpark_spark_rtl.vhd"
echo "#############################################################"
