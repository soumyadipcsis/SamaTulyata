
The Spark readme is in the parent directory
../README.txt
