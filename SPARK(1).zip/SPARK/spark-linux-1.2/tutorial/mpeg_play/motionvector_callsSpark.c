#include "video.h"
#include "proto.h"
#include "util.h"

extern inline void ComputeForwVector_Modified (
                           int *recon_right_for_ptr,
                           int *recon_down_for_ptr,
                           int *recon_right_for_prev,
                           int *recon_down_for_prev,
                           int forw_f,
                           int full_pel_forw_vector,
                           int motion_h_forw_code, 
                           int motion_v_forw_code,
                           int motion_h_forw_r, 
                           int motion_v_forw_r);

extern inline void ComputeBackVector_Modified (
                           int *recon_right_back_ptr,
                           int *recon_down_back_ptr,
                           int *recon_right_back_prev, 
                           int *recon_down_back_prev,
                           int back_f, 
                           int full_pel_back_vector,
                           int motion_h_back_code, 
                           int motion_v_back_code,
                           int motion_h_back_r, 
                           int motion_v_back_r);

void 
ComputeForwVector(recon_right_for_ptr, recon_down_for_ptr, the_stream)
     int *recon_right_for_ptr;
     int *recon_down_for_ptr;
     VidStream *the_stream;
{

  Pict *picture;
  Macroblock *mblock;

  picture = &(the_stream->picture);
  mblock = &(the_stream->mblock);

  ComputeForwVector_Modified(recon_right_for_ptr, recon_down_for_ptr,
                             &(mblock->recon_right_for_prev), 
                             &(mblock->recon_down_for_prev),
                             (int) picture->forw_f,
                             picture->full_pel_forw_vector,
                             mblock->motion_h_forw_code, mblock->motion_v_forw_code,
                             mblock->motion_h_forw_r, mblock->motion_v_forw_r); 
}


/*
 *--------------------------------------------------------------
 *
 * ComputeBackVector --
 *
 *	Computes backward motion vector by calling ComputeVector
 *      with appropriate parameters.
 *
 * Results:
 *	Reconstructed motion vector placed in recon_right_back_ptr and
 *      recon_down_back_ptr.
 *
 * Side effects:
 *      None.
 *
 *--------------------------------------------------------------
 */

/* Modified by Sumit Gupta to remove structs for Spark */
void 
ComputeBackVector(recon_right_back_ptr, recon_down_back_ptr, the_stream)
     int *recon_right_back_ptr;
     int *recon_down_back_ptr;
     VidStream *the_stream;
{
  Pict *picture;
  Macroblock *mblock;

  picture = &(the_stream->picture);
  mblock = &(the_stream->mblock);

  ComputeBackVector_Modified(recon_right_back_ptr, recon_down_back_ptr,
                             &(mblock->recon_right_back_prev), 
                             &(mblock->recon_down_back_prev),
                             (int) picture->back_f, 
                             picture->full_pel_back_vector,
                             mblock->motion_h_back_code, mblock->motion_v_back_code,
                             mblock->motion_h_back_r, mblock->motion_v_back_r); 

}
