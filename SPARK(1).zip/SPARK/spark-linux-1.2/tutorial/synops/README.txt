
This directory contains the scripts required to synthesize the
VHDL produced by SPARK using Synopsys Design Compiler.

Sub-directories:
./dbs/
./reports/
./src/
./scripts/
	motionvector_forSpark_spark_rtl.scr
	work/

The file "motionvector_forSpark_spark_rtl.vhd" should be copied from the
"src" directory from the "mpeg_play" directory by the "runTut.csh/sh" script.

The script "motionvector_forSpark_spark_rtl.scr" under the "script"
directory can be executed using Synopsys Design Compiler as follows:
  dc_shell -f motionvector_forSpark_spark_rtl.scr > motionvector_forSpark.log

where "motionvector_forSpark.log" is the log file.

This Synopsys script generates reports in the "reports" directory
and places the synthesized data base files in the "dbs" directory.

Please read the README.txt in the ./script directory.
