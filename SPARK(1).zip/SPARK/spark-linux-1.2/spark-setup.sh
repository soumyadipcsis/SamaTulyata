export SPARK_HOME=`pwd`
export SPARK_INCLUDES=${SPARK_HOME}/include
export PATH=${SPARK_HOME}/bin:${PATH}
