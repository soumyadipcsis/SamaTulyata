            
             SPARK Parallelizing High-Level Synthesis Tool
               Version 1.2, Release Date February 5, 2004 
                    http://www.cecs.uci.edu/~spark
                            Sumit Gupta

This software is Copyright � 2003-2004 The Regents of the University of
California.  All Rights Reserved.

For Windows, please read README-win32.txt

This is the main directory for the Spark distribution.

Quick Start for Tutorial
------------------------

Make sure you are in the spark-linux-1.2 directory

source spark-setup.csh  # if you use tcsh or csh shell
OR
. spark-setup.sh        # if you use sh or bash shell - works for CYGWIN as well
OR 
spark-setup.bat         # for Native windows shell

cd tutorial/mpeg_play

source runTut.csh       # tcsh/csh
OR
. runTut.sh             # sh
OR
. runTut-win32.sh       # for CYGWIN/MINGW shells
OR
runTut.bat              # for Native Windows Shell


For details about Tutorial output, see documentation on SPARK webpage
and look at tutorial/README.txt

Complete Instructions
---------------------

Do this first: Source the script "spark-setup.csh/sh" given in this directory
as follows:
source spark-setup.csh   # if you use tcsh or csh shell
. spark-setup.sh         # if you use sh or bash shell
spark-setup.bat          # from Windows Native shell terminal

This setups the path and environment variables as required by Spark.

The sub-directories "bin" and "tutorial" contain the Spark binary
and the tutorial respectively.  Please read the Spark User Manual
and Tutorial Guide for further information.

The sub-directory "include" contains the .h files such as stdio.h etc
that are usually part of the system distribution or of GCC.  These are 
required by programs that include stdio.h or some such system file.  
You can set the path in the spark.prefs file or as the system variable 
SPARK_INCLUDES.  

NOTE for Windows: The files under the include directory will not work.
Instead, if you have to use stdio.h etc, then please either set the
SPARK_INCLUDES environment variable to point to the directory where
these files reside, or use the "-I" flag along with SPARK as follows:
spark -I /path/to/include filename.c

Reporting bugs:
    Please report bugs to              spark@cecs.uci.edu 
    with subject                       BUG: Brief description of bug.
    Since this software is unsupported, there is no guarantee to whether
    the bug will be fixed or in what time frame.   When reporting bugs
    please include as much information as possible:
     1. Program version and OS version
     2. Input file that caused bug
     3. Priority.rules and default.spark files

ACKNOWLEDGEMENTS:
    We gratefully thank the Semiconductor Research Corporation and
    Intel for financial support.

    Spark was developed primarily by Sumit Gupta and with significant
    contributions to the underlying framework by Nick Savoiu.  
    Professors Rajesh Gupta, Nikil Dutt and Alex Nicolau were the 
    primary investigators on the project. 

    We would like to thank Timothy Kam, Michael Kishinevsky, and Shai
    Rotem from Intel Strategic CAD Labs for their advice and collaboration.

COPYRIGHT
---------
This software is Copyright � 2003-2004 The Regents of the University of
California.  All Rights Reserved.

Permission to use, copy, modify, and distribute this software and its
documentation for educational, research and non-profit purposes,
without fee, and without a written agreement is hereby granted,
provided that the above copyright notice, this paragraph and the
following three paragraphs appear in all copies.

Permission to incorporate this software into commercial products or for use
in a commercial setting may be obtained by contacting:

Technology Transfer Office
9500 Gilman Drive, Mail Code 0910
University of California
La Jolla, CA 92093-0910
(858) 534-5815
invent@ucsd.edu

This software program and documentation are copyrighted by The Regents
of the University of California. The software program and
documentation are supplied "as is", without any accompanying services
from The Regents. The Regents does not warrant that the operation of
the program will be uninterrupted or error-free. The end-user
understands that the program was developed for research purposes and
is advised not to rely exclusively on the program for any reason.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. THE UNIVERSITY OF
CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS ON AN "AS
IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATIONS TO
PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
